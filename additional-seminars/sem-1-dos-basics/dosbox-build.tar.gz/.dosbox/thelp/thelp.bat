@echo off
XVIEW.EXE /Q %1
